/* eslint-disable import/prefer-default-export */
export { default as getAllWords } from './getAllWords';
export { default as createNewWord } from './createNewWord';
export { default as updateWord } from './updateWord';
export { default as deleteEntry } from './deleteEntry';
